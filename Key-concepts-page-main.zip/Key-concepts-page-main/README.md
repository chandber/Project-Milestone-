# Keyconcepts

cookies - small text that help website rember the information of the user


privacy -  referes to the protection of personal information in which involves seeing if your 


HTTP - data that is transfered throught the world wide web.

Third party company- A company that is usually external and is usally run by mall group of people or a entilerly diffrent platform.

Data Security - the pratice of protecting senstive information.
    
 <h2>Table of contents</h2>
<a href=" # gh repo clone chandber/About-Me">aboutme</a>
 <a href=" # Topic-pages-Cookies">Topic Page</a>
  <a href=" # gh repo clone chandber/Privacy">Privacy</a>
  <a href=" # gh repo clone chandber/Topic-pages-Cookies">Cookies</a>
  <a href=" #gh repo clone chandber/Key-concepts-page ">Key concepts</a>
  <a href=" gh repo clone chandber/References-and-resources-page-">References-and-resources</a>
