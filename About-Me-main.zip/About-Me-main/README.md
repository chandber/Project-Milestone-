<h2>About ME</h2>
    <p>My name is chandler Handberry and my major is in media and entertainment. I am also minoring in IT and trying to learn how to develop websites . </p>
 <h2>Table of contents</h2>
<a href=" # gh repo clone chandber/About-Me">aboutme</a>
 <a href=" # Topic-pages-Cookies">Topic Page</a>
  <a href=" # gh repo clone chandber/Privacy">Privacy</a>
  <a href=" # gh repo clone chandber/Topic-pages-Cookies">Cookies</a>
  <a href=" #gh repo clone chandber/Key-concepts-page ">Key concepts</a>
  <a href=" gh repo clone chandber/References-and-resources-page-">References-and-resources</a>
