<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="style-a.css">
</head>
<body>
    <main>
    <h1>Cookie and Privcay</h1>   
    </nav>
    <h2>Introduction</h2>
    <p> For my research I am going to do a research on cookies and privicy. Website Cookies are text that appear in browsers every time you vist a website and privcy. Cookies record users data for advertsing reason despite this affecting the clickers privcy:</p>
    <h2>Table of contents</h2>
<a href=" # gh repo clone chandber/About-Me">aboutme</a>
 <a href=" # Topic-pages-Cookies">Topic Page</a>
  <a href=" # gh repo clone chandber/Privacy">Privacy</a>
  <a href=" # Topic-pages-Cookies">Cookies</a>
  <a href=" #gh repo clone chandber/Key-concepts-page ">Key concepts</a>
  <a href=" gh repo clone chandber/References-and-resources-page-">References-and-resources</a>

