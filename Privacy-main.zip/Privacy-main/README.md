<h2>Privacy</h2>
digital anaylitics literature has received countless of online traffic from mutiple users throughout the server and user behavior to the website cookies consent mechnism by applying TA<,PMT,and DSR. There is data that is being stored by either a third party company or the government. studies have shown that there is an investigation in technology and online privacy.
 <h2>Table of contents</h2>
<a href=" # gh repo clone chandber/About-Me">aboutme</a>
 <a href=" # Topic-pages-Cookies">Topic Page</a>
  <a href=" # gh repo clone chandber/Privacy">Privacy</a>
  <a href=" # gh repo clone chandber/Topic-pages-Cookies">Cookies</a>
  <a href=" #gh repo clone chandber/Key-concepts-page ">Key concepts</a>
  <a href=" gh repo clone chandber/References-and-resources-page-">References-and-resources</a>
