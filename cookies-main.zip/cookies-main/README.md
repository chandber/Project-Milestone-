# Topic-pages-Cookies
user who use the internet are often browsing through the interents search engine such as "safari and firefox". these types of browsers uses Hyper Text Transfer Protocol(HTTP). Because of HTTPis stateless i dosen't remeber all browser request. Browser uses cookies which are basically used to accepting tracking onto  another user. However this raises mass priavcy concern depending on the webiste such as thirrd party cookies as the website is collecting data.
  
 
